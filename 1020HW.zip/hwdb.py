# -*- coding: utf-8 -*-
"""
Created on Sun Oct 23 23:29:46 2022

@author: Future
"""

import pymysql

dbsetting = {
    "host":"127.0.0.1",
    "port":3306,
    "user":"root",
    "password":"1234",
    "db":"jobs",
    "charset":"utf8"
    
    }

conn = pymysql.connect(**dbsetting)