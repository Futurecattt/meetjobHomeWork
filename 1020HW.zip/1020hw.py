# -*- coding: utf-8 -*-
"""
Created on Sat Oct 22 17:02:21 2022

@author: Future
"""

import hwdb

#功能一

def addemployee():
    print("----新增員工----")
    addid = input("員工編號 :")
    addname = input("員工姓名 :")
    addsex = input("員工性別(F/M) :")
    addtel = input("員工電話 :")
    addassume = input("加入時間 :")

    sql = "insert into employee(name,sex,tel,assume,id) values('{}','{}','{}','{}','{}')".format(addname,addsex,addtel,addassume,addid)

    cursor = hwdb.conn.cursor()
    cursor.execute(sql)
    hwdb.conn.commit()
    
    end = input("是否再新增員工(Y/N): ")
    print()
    if end == "Y" or end == "y":
        addemployee()
    else:
        return
    
#功能二

def addworks():
    print("----工作分配----")
    addemid = input("請輸入員工編號 :")
    additems = input("工作項目 :")
    addinfo = input("工作內容 :")

    sql = "insert into works(items,info,employeeid) values('{}','{}','{}')".format(additems,addinfo,addemid)

    cursor = hwdb.conn.cursor()
    cursor.execute(sql)
    hwdb.conn.commit()
    
    end = input("是否繼續分配(Y/N): ")
    print()
    if end == "Y" or end == "y":
        addworks()
    else:
        return
    
#功能三

def updateemployee():
    print("----修改員工資料----")
    print("-" * 60)
    sql = "select * from employee"

    cursor = hwdb.conn.cursor()
    cursor.execute(sql)
    hwdb.conn.commit()

    result = cursor.fetchall() 

    for row in result: 
        print(row)
    print("-" * 60)
    
    emid = input("請輸入員工編號 : ")
    sex = input("請輸入欲修改之性別 : ")
    tel = input("請輸入欲修改之電話 : ")

    sql = "update employee set sex='{}' , tel='{}' where id='{}'".format(sex,tel,emid)

    cursor.execute(sql)
    hwdb.conn.commit() 
    
    end = input("是否繼續分配(Y/N): ")
    print()
    if end == "Y" or end == "y":
        updateemployee()
    else:
        return

#功能四

def selemployee():
    print("----查詢員工資料----")
    print("-" * 22)
    sql = "select id ,name from employee"
    
    date = hwdb.conn.cursor()
    date.execute(sql)
    hwdb.conn.commit()
    
    result = date.fetchall()
    for row in result: 
        print(row)
    print("-" * 22)
    
    seid = input("請輸入員工編號 :")
    sql = "select * from employee where id='{}' ".format(seid)
    cursor = hwdb.conn.cursor()
    cursor.execute(sql)
    hwdb.conn.commit()

    result = cursor.fetchall()
    for col in result: 
        print("姓名:",col[0])
        print("性別:",col[1])
        print("電話:",col[2])
        print("加入日期:",col[3])
    
    end = input("是否要查詢其他員工資料(Y/N): ")
    print()
    if end == "Y" or end == "y":
        selemployee()
    else:
        return
    
#功能五
    
def selemwork():
    print("----查詢工作內容----")
    print("-" * 22)
    sql = "select id ,name from employee"
    
    date = hwdb.conn.cursor()
    date.execute(sql)
    hwdb.conn.commit()
    
    result = date.fetchall()
    for row in result: 
        print(row)
    print("-" * 22)
    
    seid = input("請輸入員工編號 :")
    sql = "select name,items,info from employee e ,works w where id='{}' and e.id = w.employeeid".format(seid);

    cursor = hwdb.conn.cursor()
    cursor.execute(sql)
    hwdb.conn.commit()

    result = cursor.fetchall()
    for row in result: 
        print(row)
    
    end = input("是否要查詢其他員工工作(Y/N): ")
    print()
    if end == "Y" or end == "y":
        selemwork()
    else:
        return

  
def index():
    print("----員工管理系統----")
    print("-" * 20)
    print("1.新增員工")
    print("2.工作調整")
    print("3.修改員工資料")
    print("4.查詢員工資料")
    print("5.查詢工作內容")
    print("6.登出管理系統")
    print("-" * 20)
    
    
def main():
    while True:
        index()
        se = int(input("請選擇執行項目:"))
        print()
        if se == 1:
            addemployee()
        elif se == 2:
            addworks()
        elif se == 3:
            updateemployee()
        elif se == 4:
            selemployee()
        elif se == 5:
            selemwork()
        elif se == 6:
            break
    
#主程式
main()

